// Helper function for cronjob
