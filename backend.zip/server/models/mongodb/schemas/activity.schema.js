module.exports = {
  action_type: { type: 'Number' },
  action_name: { type: 'String' },
  content: { type: 'String' },
  object_type: { type: 'Number' },
  object_title: { type: 'String' },
  object_id: { type: 'String' },
  object_data: { type: 'mixed' },
  date: { type: 'Date' }
};
